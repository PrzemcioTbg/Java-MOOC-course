public class Multiplication {

    public static void main(String[] args) {

        int a = 1337;
        int b = 42;

        // Program your solution here. Remember to use variables a and b!

        int result = a * b;
        System.out.println("Multiplication of 1337 and 42 = " + result);
        System.out.println(a + " * " + b + " = " + (a*b));
    }

}
