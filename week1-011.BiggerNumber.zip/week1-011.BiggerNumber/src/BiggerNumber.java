
import java.util.Scanner;

public class BiggerNumber {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        System.out.println("Enter two numbers: ");

        double a = Double.parseDouble(reader.nextLine());
        double b = Double.parseDouble(reader.nextLine());

        double c = Math.max(a, b);
        System.out.println("Bigger number is " + c);


//        if(a > b){
//            System.out.println("Bigger number is " + a);
//        }
//        else
//            System.out.println("Bigger number is " + b);

    }
}
