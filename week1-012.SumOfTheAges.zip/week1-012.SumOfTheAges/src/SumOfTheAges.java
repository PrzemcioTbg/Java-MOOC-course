
import java.util.Scanner;

public class SumOfTheAges {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        System.out.printf("Type first name: ");
        String name1 = reader.nextLine();
        System.out.println("Type age");
        int age1 = Integer.parseInt(reader.nextLine());

        System.out.printf("Type second name: ");
        String name2 = reader.nextLine();
        System.out.println("Type age");
        int age2 = Integer.parseInt(reader.nextLine());


        System.out.println(name1 + " and " + name2 + " are " + (age1 + age2) + " years old in total");

        // Implement your program here
    }
}
