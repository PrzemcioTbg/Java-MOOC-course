
import nhlstats.NHLStatistics;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Top ten by goals");
        NHLStatistics.sortByGoals();
        NHLStatistics.top(10);

        System.out.println("\nTop 25 based on penalty amounts");
        NHLStatistics.sortByPenalties();
        NHLStatistics.top(25);

        System.out.println("\nStatistics of Sidney Crosby");
        NHLStatistics.searchByPlayer("Sidney Crosby");

        System.out.println("\nStatistics of Philadelphia Flyers");
        NHLStatistics.teamStatistics("PHI");

        System.out.println("Players of Anaheim ordered by points");
        NHLStatistics.teamStatistics("ANA");
    }

}
